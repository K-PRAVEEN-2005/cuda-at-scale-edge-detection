// main.cu
//
// CUDA at Scale — Batch Image Edge Detection
//
// Reads every image in an input directory, converts each to grayscale and
// runs a Sobel edge-detection convolution entirely on the GPU, then writes
// the results to an output directory. Designed to process a large batch
// (hundreds) of small-to-medium images in a single program invocation, with
// one CUDA kernel launch per image and per-image timing captured via CUDA
// events so that execution can be verified afterward from the log output.
//
// Usage:
//   ./bin/edge_detect --input <dir> --output <dir> [--threshold <0-255>]
//                      [--verbose]
//
// Author: (student submission)

#include <cuda_runtime.h>

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

namespace fs = std::filesystem;

// ---------------------------------------------------------------------------
// Error-checking helper
// ---------------------------------------------------------------------------
#define CUDA_CHECK(call)                                                    \
  do {                                                                      \
    cudaError_t err = (call);                                               \
    if (err != cudaSuccess) {                                               \
      std::cerr << "CUDA error at " << __FILE__ << ":" << __LINE__ << " — " \
                << cudaGetErrorString(err) << std::endl;                    \
      std::exit(EXIT_FAILURE);                                              \
    }                                                                       \
  } while (0)

// ---------------------------------------------------------------------------
// Device kernels
// ---------------------------------------------------------------------------

// Converts an interleaved RGB (or RGBA) byte image to single-channel
// grayscale using the standard luminosity weights.
__global__ void RgbToGrayscaleKernel(const unsigned char* rgb_in,
                                      unsigned char* gray_out, int width,
                                      int height, int channels) {
  int x = blockIdx.x * blockDim.x + threadIdx.x;
  int y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x >= width || y >= height) return;

  int idx = y * width + x;
  const unsigned char* px = rgb_in + idx * channels;
  float gray = 0.299f * px[0] + 0.587f * px[1] + 0.114f * px[2];
  gray_out[idx] = static_cast<unsigned char>(gray);
}

// Applies a 3x3 Sobel operator (both Gx and Gy) to a grayscale image and
// writes the thresholded gradient magnitude to the output buffer.
__global__ void SobelEdgeKernel(const unsigned char* gray_in,
                                 unsigned char* edge_out, int width,
                                 int height, int threshold) {
  int x = blockIdx.x * blockDim.x + threadIdx.x;
  int y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x >= width || y >= height) return;

  // Replicate border pixels so edges of the image are still processed.
  auto Sample = [&](int sx, int sy) -> int {
    sx = min(max(sx, 0), width - 1);
    sy = min(max(sy, 0), height - 1);
    return gray_in[sy * width + sx];
  };

  int gx = -Sample(x - 1, y - 1) - 2 * Sample(x - 1, y) - Sample(x - 1, y + 1) +
            Sample(x + 1, y - 1) + 2 * Sample(x + 1, y) + Sample(x + 1, y + 1);

  int gy = -Sample(x - 1, y - 1) - 2 * Sample(x, y - 1) - Sample(x + 1, y - 1) +
            Sample(x - 1, y + 1) + 2 * Sample(x, y + 1) + Sample(x + 1, y + 1);

  int magnitude = static_cast<int>(sqrtf(static_cast<float>(gx * gx + gy * gy)));
  magnitude = min(magnitude, 255);

  edge_out[y * width + x] = (magnitude >= threshold) ? 255 : 0;
}

// ---------------------------------------------------------------------------
// Host-side helpers
// ---------------------------------------------------------------------------

struct CliArgs {
  std::string input_dir;
  std::string output_dir;
  int threshold = 60;
  bool verbose = false;
};

void PrintUsage(const char* prog_name) {
  std::cout << "Usage: " << prog_name
            << " --input <dir> --output <dir> [--threshold <0-255>] "
               "[--verbose]\n"
            << "\n"
            << "  --input      Directory containing input images "
               "(png/jpg/bmp).\n"
            << "  --output     Directory where edge-detected images are "
               "written.\n"
            << "  --threshold  Gradient-magnitude threshold for edges "
               "(default: 60).\n"
            << "  --verbose    Print per-image timing information.\n";
}

CliArgs ParseArgs(int argc, char** argv) {
  CliArgs args;
  for (int i = 1; i < argc; ++i) {
    std::string arg = argv[i];
    if (arg == "--input" && i + 1 < argc) {
      args.input_dir = argv[++i];
    } else if (arg == "--output" && i + 1 < argc) {
      args.output_dir = argv[++i];
    } else if (arg == "--threshold" && i + 1 < argc) {
      args.threshold = std::atoi(argv[++i]);
    } else if (arg == "--verbose") {
      args.verbose = true;
    } else if (arg == "--help" || arg == "-h") {
      PrintUsage(argv[0]);
      std::exit(EXIT_SUCCESS);
    } else {
      std::cerr << "Unknown or malformed argument: " << arg << std::endl;
      PrintUsage(argv[0]);
      std::exit(EXIT_FAILURE);
    }
  }
  if (args.input_dir.empty() || args.output_dir.empty()) {
    std::cerr << "Error: --input and --output are required.\n";
    PrintUsage(argv[0]);
    std::exit(EXIT_FAILURE);
  }
  return args;
}

bool IsSupportedImage(const fs::path& p) {
  std::string ext = p.extension().string();
  for (auto& c : ext) c = std::tolower(c);
  return ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".bmp";
}

// Runs the grayscale + Sobel pipeline on a single image entirely on the GPU.
// Returns the GPU kernel execution time in milliseconds.
float ProcessImage(const fs::path& input_path, const fs::path& output_path) {
  int width, height, channels;
  unsigned char* h_img =
      stbi_load(input_path.string().c_str(), &width, &height, &channels, 3);
  if (h_img == nullptr) {
    std::cerr << "  Failed to load: " << input_path << std::endl;
    return -1.0f;
  }
  channels = 3;  // stbi_load was forced to 3 channels above.

  size_t rgb_bytes = static_cast<size_t>(width) * height * channels;
  size_t gray_bytes = static_cast<size_t>(width) * height;

  unsigned char *d_rgb, *d_gray, *d_edges;
  CUDA_CHECK(cudaMalloc(&d_rgb, rgb_bytes));
  CUDA_CHECK(cudaMalloc(&d_gray, gray_bytes));
  CUDA_CHECK(cudaMalloc(&d_edges, gray_bytes));
  CUDA_CHECK(cudaMemcpy(d_rgb, h_img, rgb_bytes, cudaMemcpyHostToDevice));

  dim3 block(16, 16);
  dim3 grid((width + block.x - 1) / block.x, (height + block.y - 1) / block.y);

  cudaEvent_t start, stop;
  CUDA_CHECK(cudaEventCreate(&start));
  CUDA_CHECK(cudaEventCreate(&stop));

  CUDA_CHECK(cudaEventRecord(start));
  RgbToGrayscaleKernel<<<grid, block>>>(d_rgb, d_gray, width, height, channels);
  CUDA_CHECK(cudaGetLastError());
  SobelEdgeKernel<<<grid, block>>>(d_gray, d_edges, width, height, 60);
  CUDA_CHECK(cudaGetLastError());
  CUDA_CHECK(cudaEventRecord(stop));
  CUDA_CHECK(cudaEventSynchronize(stop));

  float ms = 0.0f;
  CUDA_CHECK(cudaEventElapsedTime(&ms, start, stop));

  std::vector<unsigned char> h_edges(gray_bytes);
  CUDA_CHECK(cudaMemcpy(h_edges.data(), d_edges, gray_bytes, cudaMemcpyDeviceToHost));

  stbi_write_png(output_path.string().c_str(), width, height, 1,
                  h_edges.data(), width);

  cudaFree(d_rgb);
  cudaFree(d_gray);
  cudaFree(d_edges);
  cudaEventDestroy(start);
  cudaEventDestroy(stop);
  stbi_image_free(h_img);

  return ms;
}

int main(int argc, char** argv) {
  CliArgs args = ParseArgs(argc, argv);

  int device_count = 0;
  CUDA_CHECK(cudaGetDeviceCount(&device_count));
  if (device_count == 0) {
    std::cerr << "No CUDA-capable GPU detected. This program requires a "
                  "GPU to run.\n";
    return EXIT_FAILURE;
  }
  cudaDeviceProp prop;
  CUDA_CHECK(cudaGetDeviceProperties(&prop, 0));
  std::cout << "Using GPU device 0: " << prop.name << std::endl;

  if (!fs::exists(args.output_dir)) {
    fs::create_directories(args.output_dir);
  }

  std::vector<fs::path> input_files;
  for (const auto& entry : fs::directory_iterator(args.input_dir)) {
    if (entry.is_regular_file() && IsSupportedImage(entry.path())) {
      input_files.push_back(entry.path());
    }
  }
  std::sort(input_files.begin(), input_files.end());

  if (input_files.empty()) {
    std::cerr << "No supported images (.png/.jpg/.jpeg/.bmp) found in "
              << args.input_dir << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "Found " << input_files.size() << " images in "
            << args.input_dir << std::endl;
  std::cout << "Edge threshold: " << args.threshold << std::endl;

  auto wall_start = std::chrono::high_resolution_clock::now();
  float total_gpu_ms = 0.0f;
  int succeeded = 0;

  for (size_t i = 0; i < input_files.size(); ++i) {
    const fs::path& in_path = input_files[i];
    fs::path out_path =
        fs::path(args.output_dir) / (in_path.stem().string() + "_edges.png");

    float ms = ProcessImage(in_path, out_path);
    if (ms >= 0.0f) {
      succeeded++;
      total_gpu_ms += ms;
      if (args.verbose) {
        std::cout << "  [" << (i + 1) << "/" << input_files.size() << "] "
                  << in_path.filename().string() << " -> "
                  << out_path.filename().string() << "  (" << ms << " ms GPU)"
                  << std::endl;
      }
    }
  }

  auto wall_end = std::chrono::high_resolution_clock::now();
  double wall_ms =
      std::chrono::duration<double, std::milli>(wall_end - wall_start).count();

  std::cout << "\n=== Summary ===" << std::endl;
  std::cout << "Images processed successfully: " << succeeded << "/"
            << input_files.size() << std::endl;
  std::cout << "Total GPU kernel time:  " << total_gpu_ms << " ms" << std::endl;
  std::cout << "Total wall-clock time:  " << wall_ms << " ms" << std::endl;
  std::cout << "Average GPU time/image: " << (total_gpu_ms / succeeded)
            << " ms" << std::endl;
  std::cout << "Output written to: " << args.output_dir << std::endl;

  return (succeeded == static_cast<int>(input_files.size())) ? EXIT_SUCCESS
                                                               : EXIT_FAILURE;
}
