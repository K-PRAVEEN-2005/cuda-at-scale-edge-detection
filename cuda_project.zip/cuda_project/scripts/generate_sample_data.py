#!/usr/bin/env python3
"""Generates synthetic sample images for the batch edge-detection project.

Produces 200 small (128x128) PNG images containing random geometric shapes
(circles, rectangles, lines) with visible edges, so that Sobel edge detection
on the resulting images produces meaningful, verifiable output. This gives
the CUDA program a batch of "hundreds of small images" to process in a
single run, satisfying the assignment's data-volume requirement.
"""

import os
import random

from PIL import Image, ImageDraw

NUM_IMAGES = 200
IMG_SIZE = 128
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "input")


def random_color():
    return tuple(random.randint(0, 255) for _ in range(3))


def generate_image(seed: int) -> Image.Image:
    random.seed(seed)
    img = Image.new("RGB", (IMG_SIZE, IMG_SIZE), color=random_color())
    draw = ImageDraw.Draw(img)

    num_shapes = random.randint(3, 8)
    for _ in range(num_shapes):
        shape_type = random.choice(["circle", "rectangle", "line"])
        x0, y0 = random.randint(0, IMG_SIZE), random.randint(0, IMG_SIZE)
        x1, y1 = random.randint(0, IMG_SIZE), random.randint(0, IMG_SIZE)
        color = random_color()

        if shape_type == "circle":
            draw.ellipse([min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1)],
                         outline=color, fill=random_color(), width=2)
        elif shape_type == "rectangle":
            draw.rectangle([min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1)],
                            outline=color, fill=random_color(), width=2)
        else:
            draw.line([x0, y0, x1, y1], fill=color, width=random.randint(1, 4))

    return img


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    for i in range(NUM_IMAGES):
        img = generate_image(seed=i)
        path = os.path.join(OUTPUT_DIR, f"sample_{i:03d}.png")
        img.save(path)
    print(f"Generated {NUM_IMAGES} images of size {IMG_SIZE}x{IMG_SIZE} "
          f"in {os.path.abspath(OUTPUT_DIR)}")


if __name__ == "__main__":
    main()
